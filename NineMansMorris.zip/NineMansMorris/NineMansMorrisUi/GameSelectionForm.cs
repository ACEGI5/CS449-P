﻿using System;
using System.Windows.Forms;

namespace NineMansMorrisUi
{
    public partial class GameSelectionForm : Form
    {
        public GameSelectionForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }
    }
}