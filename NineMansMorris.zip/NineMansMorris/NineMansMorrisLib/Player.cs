﻿namespace NineMansMorrisLib
{
    public class Player
    {
        
    }
}