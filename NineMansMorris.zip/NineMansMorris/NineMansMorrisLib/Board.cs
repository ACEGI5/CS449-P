﻿namespace NineMansMorrisLib
{
    public class Board
    {
    }
}