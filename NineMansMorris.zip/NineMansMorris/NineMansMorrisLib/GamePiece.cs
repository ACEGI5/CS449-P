﻿namespace NineMansMorrisLib
{
    public class GamePiece
    {
        
    }
}