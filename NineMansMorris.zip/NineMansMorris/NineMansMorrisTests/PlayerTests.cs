﻿using NUnit.Framework;

namespace NineMansMorrisTests
{
    [TestFixture]
    public class PlayerTest
    {
        
    }
}